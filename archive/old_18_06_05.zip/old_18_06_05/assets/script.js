function markActiveMenu(active=null) {
    if(active != null) {
        var element = document.getElementById(active);
        element.classList.add("active");
    }
}
    