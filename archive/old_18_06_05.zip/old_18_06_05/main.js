var http = require("http");
var fs = require("fs");

var express = require("express");
var app = express();
app.set ('view engine', 'ejs');
app.use('/assets', express.static('assets'));

const { body,validationResult } = require('express-validator/check');
const { sanitizeBody } = require('express-validator/filter');

app.get('/',function(req, res){
  res.render("index.ejs", {menu1: "Начать", menu2: "Словарь", menu3: "Войти"});
});

app.get('/authorization',function(req, res){
  res.render("authorization.ejs");
});

app.get('/begin',function(req, res){
  res.render("begin.ejs");
});

app.listen(3000, () => console.log('Example app listening on port 3000!'));
